</main> <!-- Đóng main-content -->

<footer class="text-center py-3 bg-light mt-auto">
    <p class="mb-0">&copy; 2024 VND. Tất cả quyền được bảo lưu.</p>
</footer>
</div> <!-- Đóng d-flex container -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
