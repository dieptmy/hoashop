<div class="container-history">
    <h1 style="text-align: center;font-weight: 450;font-size: 24px;" class="mb-4">LỊCH SỬ ĐƠN HÀNG</h1>
    <div id="orderList">
        
    </div>
</div>
<script src="/app/assets/js/history.js?v=1.1"></script>