<div class="banner">
            <div class="slide-banner owl-carousel owl-theme">
                <div class="item">
                    <img src="./app/assets/image/perfume-Img/img.in.canva/slider3.jpg" class="banner-img"/>
                </div>
                <div class="item">
                    <img src="./app/assets/image/perfume-Img/img.in.canva/slider2.jpg" class="banner-img"/>
                </div>
                <div class="item">
                    <img src="./app/assets/image/perfume-Img/img.in.canva/slider5.jpg" class="banner-img" />

                </div>

            
            </div>

        </div>